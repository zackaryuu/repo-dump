Flow.Launcher.Plugin.RegFlow
==================
A plugin for the [Flow launcher](https://github.com/Flow-Launcher/Flow.Launcher).

### Usage

    rg <arguments>


### Screenshots

![RG_0](docs/imgs/root.png)

> rg HKEY_CURRENT_USER/Software/7-Zip 
![Alt text](docs/imgs/hkey_current_user_7zip.png)

