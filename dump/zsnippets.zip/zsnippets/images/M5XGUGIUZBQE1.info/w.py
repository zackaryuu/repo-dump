
from masscodepp.app import preferences


print(preferences.storagePath)

