# [1.1.0](https://github.com/massCodeIO/assistant-vscode/compare/v1.0.2...v1.1.0) (2022-08-19)


### Features

* add ability to choose from multiple fragments ([#7](https://github.com/massCodeIO/assistant-vscode/issues/7)) ([5061e3b](https://github.com/massCodeIO/assistant-vscode/commit/5061e3bd076ba1e1fb4686971842fde0f3f3801c))
* add last selected snippet to top of list ([2bfda66](https://github.com/massCodeIO/assistant-vscode/commit/2bfda6656b14ecd9c5c9528f382cb2f42669c9c7))
* sort snippet by date created ([9efea0b](https://github.com/massCodeIO/assistant-vscode/commit/9efea0b2f0c1c5e3ba9c9a65fba973c1777c2b87))



## [1.0.2](https://github.com/massCodeIO/assistant-vscode/compare/v1.0.1...v1.0.2) (2022-05-04)


### Bug Fixes

* exclude deleted snippets from fetch ([9dca298](https://github.com/massCodeIO/assistant-vscode/commit/9dca2980094bee62cb51fe2136390995b2c1be04))



## [1.0.1](https://github.com/massCodeIO/assistant-vscode/compare/v1.0.0...v1.0.1) (2022-04-27)



# 1.0.0 (2022-04-27)



