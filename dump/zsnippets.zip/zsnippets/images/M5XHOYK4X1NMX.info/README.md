# massCode assistant fo Visual Studio Code

> Required version of massCode >= 2.4.0

Quick access to massCode app

![](https://github.com/massCodeIO/assistant-vscode/raw/master/assets/command.png)

- Fetch snippets
- Search snippets
- Select to paste
- Create snippets

![](https://github.com/massCodeIO/assistant-vscode/raw/master/assets/demo.gif)